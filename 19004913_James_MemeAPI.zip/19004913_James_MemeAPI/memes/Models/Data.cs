using System.Collections.Generic;

namespace memes.Models
{
    public class Data
    {
        public List<Meme> memes { get; set; }
    }
}