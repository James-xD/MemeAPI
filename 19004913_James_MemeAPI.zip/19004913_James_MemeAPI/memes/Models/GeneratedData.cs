namespace memes.Models{
    public class GeneratedData
    {
        public string url { get; set; }
        public string page_url { get; set; }
    }

}