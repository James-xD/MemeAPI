namespace memes.Models
{
    public class Root
    {
        public bool success { get; set; }
        public Data data { get; set; }
    }
}