namespace memes.Models{
    public class GeneratedRoot
    {
        public bool success { get; set; }
        public GeneratedData data { get; set; }
    }

}
    
    